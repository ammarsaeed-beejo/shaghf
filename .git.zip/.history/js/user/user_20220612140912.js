const firebaseConfig = {
  apiKey: "AIzaSyBEfXjqap2M47gsTdYcJMEGvt1iwEVH0kY",
  authDomain: "shagf-console.firebaseapp.com",
  projectId: "shagf-console",
  storageBucket: "shagf-console.appspot.com",
  messagingSenderId: "104517493217",
  appId: "1:104517493217:web:f493f511ee6339568172a0",
  measurementId: "G-W5ZYMGPJWM",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// Initialize Firestore

var loginBtn = document.getElementById("loginbtn");

function userLogin(email, password) {
  firebase
    .auth()
    .signInWithEmailAndPassword(email, password)
    .then(function (result) {
      console.log(result);
    })
    .catch(function (error) {
      console.log(error);
    });
}

loginBtn.onclick = userLogin("adamyassersaeed@gmail.com", "123456789");
