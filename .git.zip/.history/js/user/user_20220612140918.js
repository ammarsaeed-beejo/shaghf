firebase.initializeApp(firebaseConfig);
// Initialize Firestore

var loginBtn = document.getElementById("loginbtn");

function userLogin(email, password) {
  firebase
    .auth()
    .signInWithEmailAndPassword(email, password)
    .then(function (result) {
      console.log(result);
    })
    .catch(function (error) {
      console.log(error);
    });
}

loginBtn.onclick = userLogin("adamyassersaeed@gmail.com", "123456789");
